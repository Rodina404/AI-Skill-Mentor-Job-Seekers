"""
AI Skill Mentor - Main Pipeline Orchestrator
=============================================

Ties all modules (L1-L5) together into a unified pipeline.

Usage:
    from skill_mentor_main import SkillMentorPipeline
    
    pipeline = SkillMentorPipeline()
    result = pipeline.run(
        missing_skills=skills,
        user_constraints=constraints
    )
"""

import json
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, List, Optional
import numpy as np

from skill_mentor_config import Config, default_config
from skill_mentor_utils import (
    header, ok, info, warn, row, safe_print, safe_char,
    validate_user_constraints, validate_skill_gaps,
    TermColors
)
from skill_mentor_data_loaders import DataLoader
from skill_mentor_l1_roadmap import RoadmapLogic
from skill_mentor_l2_svg import SVGGenerator
from skill_mentor_l3_progress import ProgressEngine
from skill_mentor_l4_notifications import NotificationSystem
from skill_mentor_l5_explainability import ExplainabilityLLM


class SkillMentorPipeline:
    """
    Main orchestrator for the AI Skill Mentor pipeline.
    
    Coordinates all 5 layers:
        L1: Roadmap Logic (scheduling)
        L2: SVG Generator (visualizations)
        L3: Progress Engine (tracking)
        L4: Notification System (engagement)
        L5: Explainability LLM (explanations)
    """
    
    def __init__(self, config: Optional[Config] = None):
        self.config = config or default_config
        
        # Initialize loaders
        self.data_loader = DataLoader(config)
        
        # Initialize layers (lazy)
        self._roadmap_logic: Optional[RoadmapLogic] = None
        self._svg_generator: Optional[SVGGenerator] = None
        self._explainability: Optional[ExplainabilityLLM] = None
        
        # State
        self._data_loaded = False
        self._skill_hours: Dict[str, float] = {}
        self._courses: List[Dict] = []
        self._oulad_thresholds: Dict = {}
    
    @property
    def roadmap_logic(self) -> RoadmapLogic:
        if self._roadmap_logic is None:
            self._roadmap_logic = RoadmapLogic(self.config)
        return self._roadmap_logic
    
    @property
    def svg_generator(self) -> SVGGenerator:
        if self._svg_generator is None:
            self._svg_generator = SVGGenerator(self.config)
        return self._svg_generator
    
    @property
    def explainability(self) -> ExplainabilityLLM:
        if self._explainability is None:
            self._explainability = ExplainabilityLLM(self.config)
        return self._explainability
    
    def load_data(self, force_reload: bool = False) -> Dict:
        """
        Load all data sources.
        
        Args:
            force_reload: Force reload even if already loaded
            
        Returns:
            Dictionary with skill_hours, courses, oulad_thresholds
        """
        if self._data_loaded and not force_reload:
            return {
                "skill_hours": self._skill_hours,
                "courses": self._courses,
                "oulad_thresholds": self._oulad_thresholds,
            }
        
        data = self.data_loader.load_all()
        
        self._skill_hours = data["skill_hours"]
        self._courses = data["courses"]
        self._oulad_thresholds = data["oulad_thresholds"]
        self._data_loaded = True
        
        return data
    
    def run(
        self,
        missing_skills: List[Dict],
        user_constraints: Dict,
        progress_events: Optional[List[Dict]] = None,
        simulate_stall_days: int = 0,
        skip_visualizations: bool = False,
        skip_explanations: bool = False
    ) -> Dict:
        """
        Run the full pipeline.
        
        Args:
            missing_skills: List of skill gap dictionaries
            user_constraints: User's time/deadline constraints
            progress_events: Optional list of progress update events
            simulate_stall_days: Days of inactivity to simulate (for testing)
            skip_visualizations: Skip L2 SVG generation
            skip_explanations: Skip L5 explanations
            
        Returns:
            Complete pipeline result with roadmap, progress, notifications, etc.
        """
        c = TermColors
        block = safe_char('█')
        arrow = safe_char('→')
        safe_print(f"\n{c.BOLD}{c.WHITE}{block*72}{c.END}")
        safe_print(f"{c.BOLD}{c.WHITE}  AI SKILL MENTOR - FULL PIPELINE (REFACTORED){c.END}")
        safe_print(f"{c.BOLD}{c.WHITE}  L1 Roadmap {arrow} L2 SVG {arrow} L3 Progress {arrow} L4 Notifications {arrow} L5 Explain{c.END}")
        safe_print(f"{c.BOLD}{c.WHITE}{block*72}{c.END}\n")
        
        # Load data
        self.load_data()
        
        # Score courses for relevance
        self._score_courses(missing_skills)
        
        # L1: Generate roadmap
        roadmap = self.roadmap_logic.generate(
            missing_skills=missing_skills,
            all_courses=self._courses,
            user_constraints=user_constraints,
            skill_hours=self._skill_hours
        )
        
        # Add user scores (for readiness calculation)
        roadmap["user_exp_score"] = user_constraints.get("experience_score", 0.5)
        roadmap["user_edu_score"] = user_constraints.get("education_score", 0.6)
        
        # L2: Generate visualizations
        visualizations = {}
        if not skip_visualizations:
            visualizations = self.svg_generator.generate_all(roadmap)
        
        # L3: Progress engine
        progress_engine = ProgressEngine(roadmap, self.config)
        
        if progress_events:
            progress_status = progress_engine.batch_update(progress_events)
        else:
            # Simulate some progress for demo
            progress_status = self._simulate_progress(
                progress_engine, roadmap, simulate_stall_days
            )
        
        progress_engine.print_status(progress_status)
        progress_engine.save_status()
        
        # L4: Notifications
        notif_system = NotificationSystem(roadmap, self._oulad_thresholds, self.config)
        
        last_activity = progress_status.get("last_activity")
        if simulate_stall_days > 0:
            # Override last activity for testing
            last_activity = (
                datetime.now() - timedelta(days=simulate_stall_days)
            ).isoformat()
        
        notifications = notif_system.generate(
            progress_status,
            last_activity_date=last_activity
        )
        notif_system.print_notifications(notifications)
        notif_system.save_notifications(notifications)
        
        # L5: Explanations
        explanations = {}
        if not skip_explanations:
            explanations = self.explainability.generate_all_explanations(
                roadmap, missing_skills, self._courses
            )
        
        # Print summary
        self._print_summary(roadmap, visualizations)
        
        return {
            "roadmap": roadmap,
            "progress_status": progress_status,
            "notifications": notifications,
            "explanations": explanations,
            "visualizations": visualizations,
        }
    
    def _score_courses(self, missing_skills: List[Dict]) -> None:
        """Score all courses for relevance to missing skills."""
        for course in self._courses:
            matched = sum(
                1 for gap in missing_skills
                if any(
                    gap["skill"].lower() in s.lower()
                    for s in course.get("skills_taught", [])
                )
            )
            
            relevance = matched / max(len(course.get("skills_taught", [])), 1)
            rating = course.get("rating", 4.5) / 5.0
            
            course["relevance_score"] = round(relevance, 3)
            course["final_score"] = round(relevance * 0.6 + rating * 0.4, 3)
    
    def _simulate_progress(
        self,
        engine: ProgressEngine,
        roadmap: Dict,
        stall_days: int = 0
    ) -> Dict:
        """Simulate progress for demo/testing."""
        courses_used = roadmap.get("courses_used", [])[:3]
        base_date = datetime.fromisoformat(roadmap["generated_at"])
        
        events = []
        for course in courses_used:
            for day in [3, 7, 14]:
                events.append({
                    "course_id": course["id"],
                    "pct_complete": min(100.0, day * 5.0 + np.random.uniform(-5, 5)),
                    "timestamp": (base_date + timedelta(days=day)).isoformat(),
                })
        
        return engine.batch_update(events)
    
    def _print_summary(
        self,
        roadmap: Dict,
        visualizations: Dict
    ) -> None:
        """Print final output summary."""
        header("FINAL OUTPUT SUMMARY")
        
        output_dir = self.config.paths.output_dir
        
        files = {
            "roadmap.json": "L1 - Full roadmap JSON (weeks/tasks/milestones)",
            "roadmap_timeline.svg": "L2 - Gantt timeline SVG",
            "roadmap_cards.svg": "L2 - Weekly cards SVG",
            "roadmap_report.html": "L2 - Interactive HTML report",
            "progress_status.json": "L3 - Progress tracking state",
            "notifications.json": "L4 - Generated notifications",
            "explanations.json": "L5 - Explanations (LLM or rule-based)",
        }
        
        c = TermColors
        for fname, desc in files.items():
            fpath = output_dir / fname
            size = fpath.stat().st_size if fpath.exists() else 0
            icon = f"{c.GREEN}[OK]{c.END}" if fpath.exists() else f"{c.RED}[X]{c.END}"
            print(f"  {icon}  {fname:<32} {size:>8,} bytes  - {desc}")
        
        stats = roadmap.get("summary_stats", {})
        
        print(f"\n  {c.GREEN}All outputs in: {output_dir}{c.END}")
        print(f"\n  {c.BOLD}Skills matched: {stats.get('skills_matched', 0)}/{stats.get('skills_total', 0)}{c.END}")
        print(f"\n  {c.BOLD}Real data sources used:{c.END}")
        print(f"    * O*NET Database 28.3 - {len(self._skill_hours)} skill->hours mappings")
        print(f"    * Course catalog - {len(self._courses)} courses")
        print(f"    * OULAD (Kuzilek et al., 2017) - {self._oulad_thresholds.get('total_students', 32593):,} students")
        print(f"    * Anthropic Claude API - L5 Explainability "
              f"({'enabled' if self.explainability.api_available else 'rule-based fallback'})")
        print()


def main():
    """Demo main function with sample data."""
    # Sample skill gaps (from original notebook)
    demo_skills = [
        {"skill": "DAX", "gap_score": 0.95, "similarity": 0.05, "priority": "high", 
         "market_freq": "31%", "best_match": "Excel"},
        {"skill": "Power BI", "gap_score": 0.92, "similarity": 0.08, "priority": "high", 
         "market_freq": "61%", "best_match": "Excel"},
        {"skill": "Tableau", "gap_score": 0.88, "similarity": 0.12, "priority": "high", 
         "market_freq": "65%", "best_match": "data visualization"},
        {"skill": "machine learning", "gap_score": 0.84, "similarity": 0.16, "priority": "medium", 
         "market_freq": "45%", "best_match": "Python"},
        {"skill": "data warehousing", "gap_score": 0.79, "similarity": 0.21, "priority": "medium", 
         "market_freq": "41%", "best_match": "SQL"},
        {"skill": "ETL", "gap_score": 0.76, "similarity": 0.24, "priority": "medium", 
         "market_freq": "43%", "best_match": "Python"},
        {"skill": "A/B testing", "gap_score": 0.72, "similarity": 0.28, "priority": "medium", 
         "market_freq": "38%", "best_match": "statistics"},
        {"skill": "statistics", "gap_score": 0.60, "similarity": 0.40, "priority": "low", 
         "market_freq": "68%", "best_match": "data analysis"},
    ]
    
    demo_constraints = {
        "name": "Ahmed Hassan",
        "hours_per_week": 10,
        "deadline_weeks": 16,
        "experience_score": 0.4,  # 2 years exp = 40%
        "education_score": 0.6,   # BSc = 60%
    }
    
    # Run pipeline
    pipeline = SkillMentorPipeline()
    
    result = pipeline.run(
        missing_skills=demo_skills,
        user_constraints=demo_constraints,
        simulate_stall_days=15,  # Simulate stalled user
    )
    
    return result


if __name__ == "__main__":
    main()
