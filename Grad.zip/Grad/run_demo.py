"""
AI Skill Mentor - Full Pipeline Demo
=====================================
Shows all 5 layers working together with visible output.
"""

import json
from datetime import datetime, timedelta
from pathlib import Path

# Import pipeline components
from skill_mentor_config import default_config
from skill_mentor_data_loaders import DataLoader
from skill_mentor_l1_roadmap import RoadmapLogic
from skill_mentor_l2_svg import SVGGenerator
from skill_mentor_l3_progress import ProgressEngine
from skill_mentor_l4_notifications import NotificationSystem
from skill_mentor_l5_explainability import ExplainabilityLLM
from skill_mentor_utils import safe_print, safe_char

def divider(title):
    """Print a section divider."""
    print("\n" + "=" * 60)
    print(f"  {title}")
    print("=" * 60)

def main():
    print("\n" + "*" * 60)
    print("*   AI SKILL MENTOR - FULL PIPELINE DEMO")
    print("*" * 60)
    
    # =========================================================
    # SETUP: Define user and skill gaps
    # =========================================================
    divider("SETUP: User Profile & Skill Gaps")
    
    user_constraints = {
        "name": "Farah (Demo User)",
        "hours_per_week": 10,
        "deadline": (datetime.now() + timedelta(weeks=12)).strftime("%Y-%m-%d"),
        "learning_style": "visual",
        "experience_level": "intermediate"
    }
    
    missing_skills = [
        {"skill": "Machine Learning", "current_level": 2, "target_level": 4, "priority": "high"},
        {"skill": "Python", "current_level": 3, "target_level": 5, "priority": "high"},
        {"skill": "Deep Learning", "current_level": 1, "target_level": 3, "priority": "medium"},
        {"skill": "Data Visualization", "current_level": 2, "target_level": 4, "priority": "low"},
    ]
    
    print(f"\nUser: {user_constraints['name']}")
    print(f"Available: {user_constraints['hours_per_week']} hours/week")
    print(f"Deadline: {user_constraints['deadline']}")
    print(f"\nSkill Gaps to Fill:")
    for skill in missing_skills:
        arrow = safe_char("->")
        print(f"  {safe_char('*')} {skill['skill']}: Level {skill['current_level']} {arrow} {skill['target_level']} ({skill['priority']} priority)")
    
    # =========================================================
    # LAYER 1: Generate Learning Roadmap
    # =========================================================
    divider("LAYER 1: Roadmap Logic")
    
    print("Loading course data...")
    data_loader = DataLoader(default_config)
    all_data = data_loader.load_all()
    courses = all_data.get("courses", [])
    skill_hours = all_data.get("skill_hours", {})
    print(f"  {safe_char('OK')} Loaded {len(courses)} courses")
    
    print("\nGenerating personalized roadmap...")
    roadmap_logic = RoadmapLogic(default_config)
    roadmap = roadmap_logic.generate(
        missing_skills=missing_skills,
        all_courses=courses,
        user_constraints=user_constraints,
        skill_hours=skill_hours
    )
    
    print(f"\n{safe_char('OK')} Roadmap Generated!")
    print(f"  Total weeks: {roadmap['total_weeks']}")
    print(f"  Hours/week: {roadmap['hours_per_week']}")
    print(f"  Courses selected: {len(roadmap.get('courses_used', []))}")
    
    print("\n  Weekly Schedule Preview:")
    for week in roadmap.get("weeks", [])[:4]:  # Show first 4 weeks
        buffer_mark = " (buffer)" if week.get("is_buffer") else ""
        print(f"    Week {week['week_num']}{buffer_mark}:")
        for task in week.get("tasks", [])[:2]:  # Show first 2 tasks per week
            title = task.get("title", task.get("skill", "Task"))[:40]
            hours = task.get("duration_h", 0)
            print(f"      - {title} ({hours}h)")
    if len(roadmap.get("weeks", [])) > 4:
        print(f"    ... and {len(roadmap['weeks']) - 4} more weeks")
    
    # =========================================================
    # LAYER 2: Generate SVG Visualizations
    # =========================================================
    divider("LAYER 2: SVG Generator")
    
    print("Generating visualizations...")
    svg_gen = SVGGenerator(default_config)
    
    # Timeline SVG
    timeline_svg = svg_gen.generate_timeline_svg(roadmap)
    print(f"  {safe_char('OK')} Timeline SVG: {len(timeline_svg)} chars")
    
    # Cards SVG (skill cards instead of radar)
    cards_svg = svg_gen.generate_cards_svg(roadmap)
    print(f"  {safe_char('OK')} Skill Cards SVG: {len(cards_svg)} chars")
    
    # Generate all SVGs at once
    all_svgs = svg_gen.generate_all(roadmap)
    print(f"  {safe_char('OK')} Generated {len(all_svgs)} total SVG outputs")
    
    # =========================================================
    # LAYER 3: Progress Tracking
    # =========================================================
    divider("LAYER 3: Progress Engine")
    
    print("Initializing progress tracker...")
    progress = ProgressEngine(roadmap, default_config)
    
    status = progress.get_status()
    print(f"\n  Initial Status:")
    print(f"    Overall Progress: {status['overall_pct']:.1f}%")
    print(f"    Hours Completed: {status['done_hours']}/{status['total_hours']}")
    print(f"    Readiness Score: {status['readiness_score']:.2f}")
    
    # Simulate completing some tasks
    print("\n  Simulating progress (completing first week tasks)...")
    first_week = roadmap.get("weeks", [{}])[0]
    for task in first_week.get("tasks", [])[:2]:
        course_id = task.get("course_id", "demo")
        # Use update() method with percentage complete
        progress.update(course_id, pct_complete=25.0)
    
    status = progress.get_status()
    print(f"\n  Updated Status:")
    print(f"    Overall Progress: {status['overall_pct']:.1f}%")
    print(f"    Hours Completed: {status['done_hours']}/{status['total_hours']}")
    
    # =========================================================
    # LAYER 4: Notifications
    # =========================================================
    divider("LAYER 4: Notification System")
    
    print("Checking for notifications...")
    notif_system = NotificationSystem(
        roadmap=roadmap,
        oulad_thresholds=all_data.get("oulad_thresholds"),
        config=default_config
    )
    
    # Generate all notifications based on progress status
    notifications = notif_system.generate(
        progress_status=status,
        last_activity_date=status.get("last_activity"),
        current_date=datetime.now().strftime("%Y-%m-%d")
    )
    
    print(f"\n  Generated {len(notifications)} notifications:")
    for notif in notifications[:5]:  # Show first 5
        title = notif.get("title", "Notification")[:50]
        # Remove emoji characters for Windows console compatibility
        title = ''.join(c if ord(c) < 128 else '' for c in title).strip()
        notif_type = notif.get("type", "info")
        print(f"    {safe_char('*')} [{notif_type}] {title}")
    
    # =========================================================
    # LAYER 5: Explainability (LLM/Rule-based)
    # =========================================================
    divider("LAYER 5: Explainability LLM")
    
    print("Generating explanations...")
    explainer = ExplainabilityLLM(default_config)
    
    # Check API status
    api_status = explainer._check_api()
    print(f"  API Status: {'LLM Available' if api_status else 'Rule-based (no API key)'}")
    
    # Generate explanations using actual API
    print("\n  Generating skill explanations:")
    
    # Use generate_all_explanations for full roadmap
    all_explanations = explainer.generate_all_explanations(
        roadmap=roadmap,
        gaps=missing_skills,
        all_courses=courses
    )
    
    print(f"  {safe_char('OK')} Generated {len(all_explanations.get('skill_explanations', []))} skill explanations")
    
    # Show sample explanations
    for exp in all_explanations.get("skill_explanations", [])[:2]:
        skill = exp.get("skill", "Unknown")
        text = exp.get("explanation", "")[:80]
        print(f"    {safe_char('*')} {skill}: {text}...")
    
    # Show roadmap explanation
    if all_explanations.get("roadmap_explanation"):
        print(f"\n  Roadmap Explanation:")
        preview = all_explanations["roadmap_explanation"][:100]
        print(f"    {preview}...")
    
    # =========================================================
    # FINAL SUMMARY
    # =========================================================
    divider("PIPELINE COMPLETE")
    
    print("\n  All 5 layers executed successfully!")
    print(f"\n  Summary:")
    print(f"    {safe_char('OK')} L1 Roadmap: {roadmap['total_weeks']} weeks planned")
    print(f"    {safe_char('OK')} L2 SVG: 3 visualizations generated")
    print(f"    {safe_char('OK')} L3 Progress: {status['overall_pct']:.1f}% complete")
    print(f"    {safe_char('OK')} L4 Notifications: {len(notifications)} generated")
    print(f"    {safe_char('OK')} L5 Explanations: {len(all_explanations.get('skill_explanations', []))} skills explained")
    
    # Save outputs
    output_dir = Path("demo_output")
    output_dir.mkdir(exist_ok=True)
    
    with open(output_dir / "roadmap.json", "w", encoding="utf-8") as f:
        json.dump(roadmap, f, indent=2, default=str)
    
    with open(output_dir / "timeline.svg", "w", encoding="utf-8") as f:
        f.write(timeline_svg)
    
    with open(output_dir / "status.json", "w", encoding="utf-8") as f:
        json.dump(status, f, indent=2, default=str)
    
    print(f"\n  Output files saved to: {output_dir.absolute()}")
    print("    - roadmap.json")
    print("    - timeline.svg")
    print("    - status.json")
    
    print("\n" + "*" * 60)
    print("*   DEMO COMPLETE!")
    print("*" * 60 + "\n")

if __name__ == "__main__":
    main()
