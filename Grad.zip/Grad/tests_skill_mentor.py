"""
AI Skill Mentor - Unit Tests
============================

Comprehensive tests for all modules.

Run with: python -m pytest tests_skill_mentor.py -v
Or:       python tests_skill_mentor.py

"""

import json
import unittest
from datetime import datetime, timedelta
from pathlib import Path
from unittest.mock import MagicMock, patch
import tempfile

# Import modules to test
from skill_mentor_config import (
    Config, default_config, PathConfig, SkillPrerequisites
)
from skill_mentor_utils import (
    validate_user_constraints, validate_skill_gaps, normalize_skill_name,
    SimpleCache, retry, ValidationError, RetryError
)


class TestConfig(unittest.TestCase):
    """Test configuration module."""
    
    def test_default_config_exists(self):
        """Default config should be accessible."""
        self.assertIsNotNone(default_config)
        self.assertIsInstance(default_config, Config)
    
    def test_config_has_all_sections(self):
        """Config should have all required sections."""
        self.assertIsNotNone(default_config.paths)
        self.assertIsNotNone(default_config.network)
        self.assertIsNotNone(default_config.skill_hours)
        self.assertIsNotNone(default_config.roadmap)
        self.assertIsNotNone(default_config.progress)
        self.assertIsNotNone(default_config.notifications)
        self.assertIsNotNone(default_config.explainability)
    
    def test_skill_hours_defaults(self):
        """Skill hours should have reasonable defaults."""
        hours = default_config.skill_hours
        self.assertGreater(hours.default_hours, 0)
    
    def test_path_config_creates_dirs(self):
        """PathConfig should create output directory."""
        with tempfile.TemporaryDirectory() as tmpdir:
            paths = PathConfig(output_dir=Path(tmpdir) / "output")
            self.assertTrue(paths.output_dir.exists())


class TestSkillPrerequisites(unittest.TestCase):
    """Test skill prerequisites DAG."""
    
    def setUp(self):
        self.prereqs = SkillPrerequisites()
    
    def test_get_prerequisites_known_skill(self):
        """Known skill should return prerequisites."""
        prereqs = self.prereqs.get_prerequisites("machine learning")
        self.assertIsInstance(prereqs, list)
    
    def test_get_prerequisites_unknown_skill(self):
        """Unknown skill should return empty list."""
        prereqs = self.prereqs.get_prerequisites("some_unknown_skill_xyz")
        self.assertEqual(prereqs, [])
    
    def test_learning_order_handles_empty(self):
        """Empty skill list should return empty list."""
        ordered = self.prereqs.get_learning_order([])
        self.assertEqual(ordered, [])
    
    def test_learning_order_handles_unknown(self):
        """Unknown skills should still be included."""
        skills = ["unknown_skill_abc", "Python"]
        ordered = self.prereqs.get_learning_order(skills)
        self.assertIn("unknown_skill_abc", ordered)


class TestValidation(unittest.TestCase):
    """Test input validation functions."""
    
    def test_validate_user_constraints_valid(self):
        """Valid constraints should pass."""
        constraints = {
            "name": "Test User",
            "hours_per_week": 10,
            "deadline_weeks": 12
        }
        result = validate_user_constraints(constraints)
        self.assertIsInstance(result, dict)
        self.assertEqual(result["hours_per_week"], 10)
    
    def test_validate_user_constraints_missing_name(self):
        """Missing name should raise ValidationError."""
        constraints = {"hours_per_week": 10, "deadline_weeks": 12}
        with self.assertRaises(ValidationError):
            validate_user_constraints(constraints)
    
    def test_validate_skill_gaps_valid(self):
        """Valid skill gaps should return validated list."""
        gaps = [
            {"skill": "Python", "gap_score": 0.8, "priority": "high"},
        ]
        result = validate_skill_gaps(gaps)
        self.assertIsInstance(result, list)
        self.assertEqual(result[0]["skill"], "Python")
    
    def test_validate_skill_gaps_empty(self):
        """Empty skill list should raise ValidationError."""
        with self.assertRaises(ValidationError):
            validate_skill_gaps([])


class TestNormalizeSkillName(unittest.TestCase):
    """Test skill name normalization."""
    
    def test_normalize_lowercase(self):
        """Should lowercase."""
        self.assertEqual(normalize_skill_name("Python"), "python")
    
    def test_normalize_strip_whitespace(self):
        """Should strip whitespace."""
        self.assertEqual(normalize_skill_name("  python  "), "python")
    
    def test_normalize_collapse_spaces(self):
        """Should collapse multiple spaces."""
        result = normalize_skill_name("machine   learning")
        self.assertEqual(result, "machine learning")


class TestSimpleCache(unittest.TestCase):
    """Test simple caching."""
    
    def test_cache_set_get(self):
        """Basic set/get should work."""
        cache = SimpleCache(ttl_seconds=60)
        cache.set("key1", "value1")
        self.assertEqual(cache.get("key1"), "value1")
    
    def test_cache_miss(self):
        """Missing key should return None."""
        cache = SimpleCache(ttl_seconds=60)
        self.assertIsNone(cache.get("nonexistent"))
    
    def test_cache_clear(self):
        """Clear should empty cache."""
        cache = SimpleCache(ttl_seconds=60)
        cache.set("key1", "value1")
        cache.clear()
        self.assertIsNone(cache.get("key1"))


class TestRetryDecorator(unittest.TestCase):
    """Test retry decorator."""
    
    def test_retry_success_first_try(self):
        """Should succeed without retry if no error."""
        call_count = 0
        
        @retry(max_attempts=3, delay=0.01)
        def succeed():
            nonlocal call_count
            call_count += 1
            return "success"
        
        result = succeed()
        self.assertEqual(result, "success")
        self.assertEqual(call_count, 1)
    
    def test_retry_exhausted(self):
        """Should raise RetryError after max attempts."""
        call_count = 0
        
        @retry(max_attempts=3, delay=0.01)
        def always_fail():
            nonlocal call_count
            call_count += 1
            raise ValueError("permanent error")
        
        with self.assertRaises(RetryError):
            always_fail()
        
        self.assertEqual(call_count, 3)


class TestRoadmapLogic(unittest.TestCase):
    """Test L1 Roadmap Logic."""
    
    def setUp(self):
        from skill_mentor_l1_roadmap import RoadmapLogic
        self.logic = RoadmapLogic(default_config)
    
    def test_generate_returns_required_keys(self):
        """Generated roadmap should have required keys."""
        skills = [
            {"skill": "Python", "gap_score": 0.8, "priority": "high"},
        ]
        courses = [
            {"id": "c1", "title": "Python Course", "skills_taught": ["Python"], 
             "duration_hours": 20, "rating": 4.5, "provider": "Test"},
        ]
        constraints = {"hours_per_week": 10, "deadline_weeks": 12}
        
        roadmap = self.logic.generate(skills, courses, constraints, {})
        
        self.assertIn("weeks", roadmap)
        self.assertIn("total_weeks", roadmap)
        self.assertIn("generated_at", roadmap)
    
    def test_generate_respects_deadline(self):
        """Roadmap should not exceed deadline."""
        skills = [
            {"skill": "Python", "gap_score": 0.8, "priority": "high"},
        ]
        courses = [
            {"id": "c1", "title": "Python Course", "skills_taught": ["Python"], 
             "duration_hours": 20, "rating": 4.5, "provider": "Test"},
        ]
        constraints = {"hours_per_week": 10, "deadline_weeks": 12}
        
        roadmap = self.logic.generate(skills, courses, constraints, {})
        
        self.assertLessEqual(roadmap["total_weeks"], 12)


class TestProgressEngine(unittest.TestCase):
    """Test L3 Progress Engine."""
    
    def setUp(self):
        from skill_mentor_l3_progress import ProgressEngine
        self.roadmap = {
            "weeks": [
                {"week_num": 1, "tasks": [{"course_id": "c1", "title": "Test", "duration_h": 5}]},
            ],
            "courses_used": [{"id": "c1", "title": "Test Course", "hours": 10}],
            "total_weeks": 1,
        }
        self.engine = ProgressEngine(self.roadmap, default_config)
    
    def test_initial_state(self):
        """Initial progress should be 0%."""
        status = self.engine.get_status()
        # Actual key is overall_pct
        self.assertEqual(status["overall_pct"], 0.0)


class TestSVGGenerator(unittest.TestCase):
    """Test L2 SVG Generator."""
    
    def setUp(self):
        from skill_mentor_l2_svg import SVGGenerator
        self.generator = SVGGenerator(default_config)
    
    def test_generate_timeline(self):
        """Should generate valid SVG."""
        roadmap = {
            "weeks": [
                {"week_num": 1, "tasks": [{"skill": "Python", "duration_h": 5, "type": "learn"}], "is_buffer": False},
            ],
            "total_weeks": 1,
            "hours_per_week": 10,
            "generated_at": datetime.now().isoformat(),
            "user": "Test User",
        }
        
        svg = self.generator.generate_timeline_svg(roadmap)
        
        self.assertIn("<svg", svg)
        self.assertIn("</svg>", svg)


class TestSemanticMatcher(unittest.TestCase):
    """Test semantic skill matching."""
    
    def setUp(self):
        from skill_mentor_semantic import SemanticMatcher
        self.matcher = SemanticMatcher(default_config)
    
    def test_match_exact(self):
        """Exact match should return high similarity."""
        # compute_similarity returns (score, matched_skill) tuple
        score, matched = self.matcher.compute_similarity("python", ["python", "java"])
        self.assertGreater(score, 0.9)
        self.assertEqual(matched, "python")
    
    def test_match_similar(self):
        """Similar skills should have moderate similarity."""
        score, matched = self.matcher.compute_similarity("machine learning", ["deep learning", "data science"])
        self.assertGreater(score, 0.3)


class TestExplainabilityLLM(unittest.TestCase):
    """Test L5 Explainability."""
    
    def setUp(self):
        from skill_mentor_l5_explainability import ExplainabilityLLM
        self.llm = ExplainabilityLLM(default_config)
    
    def test_rule_based_fallback(self):
        """Rule-based fallback should work without API."""
        gap = {"skill": "Python", "gap_score": 0.8, "market_freq": "50%", "best_match": "none", "similarity": 0.0}
        course = {"title": "Python Course", "platform": "Test", "rating": 4.5, "reviews": 1000, "hours": 20}
        
        result = self.llm.explain_gap(gap, course)
        
        self.assertIn("skill_explanation", result)
        self.assertIn("course_explanation", result)


if __name__ == "__main__":
    unittest.main()
